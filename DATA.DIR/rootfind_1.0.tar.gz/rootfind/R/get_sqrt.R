mySqrt <- function(x) {
   if (!is.numeric(x)) {
        stop("The argument needs to be a number")
   }
   if (x < 0) {
        retval <- sqrt(as.complex(x))
   } else {
        retval <- sqrt(x)
   }
   return(retval)
}
